# Future Places MVP v2

## Netlify
Build command: `npm run build`
Publish directory: `dist`

## Local
`npm install` then `npm run dev`

Features: smart keyword search, categories, nearby/popular/new sections, saved places, business details, verification status, GPS, Google Maps directions, WhatsApp, call, multi-step business registration.
